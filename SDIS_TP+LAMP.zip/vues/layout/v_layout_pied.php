<div id="pied">
		<p class="float-center">MVC - Hazparneko Suhiltzaileak</p>
</div>
</body>
</html>
