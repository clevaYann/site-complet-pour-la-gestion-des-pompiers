﻿<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="alert alert-dismissible alert-success">
              <button type="button" class="close" data-dismiss="alert"></button>
              <strong>Ajout sapeur réussi ! </strong> <a href="index.php?controleur=gererAdministration&action=listeSapeurs" class="alert-link">FERMER le message</a>.
            </div>
        </div>
    </div>
</div>