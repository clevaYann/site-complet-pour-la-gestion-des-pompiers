<div class="container">
  <div class="row">
    <div class="col-lg-6">
      <div class="alert alert-dismissible alert-danger">
        <button type="button" class="close" data-dismiss="alert"></button>
        <strong>Cette adresse email existe déjà dans la base de données. </strong> <a href="index.php?controleur=gererInscriptions&action=demandeInscription" class="alert-link">NOUVEL ESSAI</a>
      </div>
    </div>
  </div>
</div>