﻿<div class="container">
    <div class="row">
        <div class="col-lg-5">
            <div class="alert alert-dismissible alert-danger">
              <button type="button" class="close" data-dismiss="alert"></button>
              <strong>Erreur identifiant ou mot de passe</strong> <a href="index.php?controleur=gererAdministration&action=demandeAuthentification" class="alert-link">Veuillez recommencer</a>
            </div>
        </div>
    </div>
</div>