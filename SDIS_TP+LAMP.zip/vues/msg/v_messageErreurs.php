﻿<div class="container">
    <div class="alert alert-dismissible alert-danger">
        <button type="button" class="close" data-dismiss="alert"></button>
        <strong>Les deux adresses emails ne sont pas identiques. </strong>
        <a href="index.php?controleur=gererInscriptions&action=demandeInscription" class="alert-link">Nouvel essai</a>
    </div>
</div>