﻿<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="alert alert-dismissible alert-success">
              <button type="button" class="close" data-dismiss="alert"></button>
              <strong>Inscrition réussie!</strong> Vous recevrez un mail pour vous donner la date de la session de tests <a href="index.php?controleur=informer&action=demandeAccueil" class="alert-link">RETOUR à l'accueil</a>
            </div>
        </div>
    </div>
</div>